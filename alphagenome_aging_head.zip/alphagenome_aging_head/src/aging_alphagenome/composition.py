"""Sequence-composition utilities for shortcut/confound analysis."""

from __future__ import annotations

from collections import Counter
import hashlib
import math
import random

BASES = ("A", "C", "G", "T")
DINUCLEOTIDES = tuple(a + b for a in BASES for b in BASES)


def canonical_sequence(sequence: str) -> str:
    return "".join(base for base in sequence.upper() if base in BASES)


def base_counts(sequence: str) -> dict[str, int]:
    sequence = sequence.upper()
    return {base: sequence.count(base) for base in BASES}


def canonical_count(sequence: str) -> int:
    return sum(base_counts(sequence).values())


def gc_count(sequence: str) -> int:
    counts = base_counts(sequence)
    return counts["G"] + counts["C"]


def base_fractions(sequence: str) -> dict[str, float]:
    counts = base_counts(sequence)
    total = sum(counts.values())
    if total == 0:
        return {base: 0.0 for base in BASES}
    return {base: counts[base] / total for base in BASES}


def dinucleotide_counts(sequence: str) -> dict[str, int]:
    sequence = sequence.upper()
    counts = Counter(
        sequence[index : index + 2]
        for index in range(max(0, len(sequence) - 1))
        if sequence[index] in BASES and sequence[index + 1] in BASES
    )
    return {dinucleotide: counts.get(dinucleotide, 0) for dinucleotide in DINUCLEOTIDES}


def dinucleotide_fractions(sequence: str) -> dict[str, float]:
    counts = dinucleotide_counts(sequence)
    total = sum(counts.values())
    if total == 0:
        return {dinucleotide: 0.0 for dinucleotide in DINUCLEOTIDES}
    return {dinucleotide: counts[dinucleotide] / total for dinucleotide in DINUCLEOTIDES}


def shannon_entropy(sequence: str) -> float:
    fractions = base_fractions(sequence)
    return -sum(
        fraction * math.log2(fraction)
        for fraction in fractions.values()
        if fraction > 0.0
    )


def cpg_fraction(sequence: str) -> float:
    fractions = dinucleotide_fractions(sequence)
    return fractions["CG"]


def sequence_features(sequence: str) -> dict[str, float | int]:
    sequence = sequence.upper()
    counts = base_counts(sequence)
    fractions = base_fractions(sequence)
    dinucleotides = dinucleotide_fractions(sequence)
    canonical = sum(counts.values())
    features: dict[str, float | int] = {
        "length": len(sequence),
        "canonical_count": canonical,
        "ambiguous_fraction": 1.0 - canonical / len(sequence) if sequence else 1.0,
        "gc_count": counts["G"] + counts["C"],
        "gc_fraction": fractions["G"] + fractions["C"],
        "at_fraction": fractions["A"] + fractions["T"],
        "cpg_fraction": dinucleotides["CG"],
        "shannon_entropy": shannon_entropy(sequence),
    }
    for base in BASES:
        features[f"count_{base}"] = counts[base]
        features[f"fraction_{base}"] = fractions[base]
    for dinucleotide in DINUCLEOTIDES:
        features[f"dinuc_{dinucleotide}"] = dinucleotides[dinucleotide]
    return features


def composition_match(
    candidate: str,
    target: str,
    *,
    gc_count_tolerance: int,
    base_fraction_tolerance: float,
    dinucleotide_l1_tolerance: float,
) -> bool:
    """Return whether candidate is a stringent low-order composition match."""

    if abs(gc_count(candidate) - gc_count(target)) > gc_count_tolerance:
        return False
    candidate_bases = base_fractions(candidate)
    target_bases = base_fractions(target)
    if max(abs(candidate_bases[b] - target_bases[b]) for b in BASES) > base_fraction_tolerance:
        return False
    candidate_dinuc = dinucleotide_fractions(candidate)
    target_dinuc = dinucleotide_fractions(target)
    l1 = sum(abs(candidate_dinuc[k] - target_dinuc[k]) for k in DINUCLEOTIDES)
    return l1 <= dinucleotide_l1_tolerance


def stable_seed(seed: int, value: str) -> int:
    digest = hashlib.sha256(f"{seed}|{value}".encode()).digest()
    return int.from_bytes(digest[:8], "big", signed=False)


def mononucleotide_shuffle(sequence: str, *, seed: int, key: str = "") -> str:
    """Shuffle positions while preserving every character count exactly."""

    values = list(sequence.upper())
    random.Random(stable_seed(seed, key)).shuffle(values)
    return "".join(values)
